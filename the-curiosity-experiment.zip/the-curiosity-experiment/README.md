# The Curiosity Experiment

A multilingual editorial-style website exploring human curiosity. Built with React, TypeScript and Vite.

## Languages
- English
- العربية
- کوردی سۆرانی

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

Created by matinmhe.
