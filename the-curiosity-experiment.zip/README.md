# The Curiosity Experiment

A multilingual editorial experience in Kurdish Sorani, Arabic and English.

## Run locally
```bash
npm install
npm run dev
```

## Build for deployment
```bash
npm run build
```

## Deploy
Import this repository into Vercel. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.

The QR generator creates a real QR code only after you enter a published HTTPS URL.

Created by: matinmhe
Instagram: https://instagram.com/matinmhe
TikTok: https://tiktok.com/@matinmhe
